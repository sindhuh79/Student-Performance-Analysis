# Student Academic Performance Analysis — Working Model

This is a fully working implementation of the internship report "Student
Academic Performance Analysis Using SQL and Data Analytics". Every step
actually runs — the data is generated with the same structure and data-quality
issues described in the report, cleaned exactly per Section 7.2, loaded into a
real SQLite database, queried with the exact SQL from Section 8, and analyzed/
visualized with the exact methods from Sections 9–10.

## How to run it (in order)

```bash
pip install pandas numpy matplotlib seaborn tabulate
python 01_generate_raw_data.py     # creates raw_student_data.csv (490 rows, with issues)
python 02_clean_data.py            # creates cleaned_student_data.csv (480 rows, 0 missing)
python 03_sql_component.py         # creates student_performance.db + sql_query_results.md
python 04_analytics.py             # creates statistical_summary.csv + correlation_matrix.csv
python 05_visualizations.py        # creates charts/*.png (all 8 report figures)
```

## Files produced

| File | What it is |
|---|---|
| `raw_student_data.csv` | 490-row raw dataset with duplicates, missing values, inconsistent casing, and 2 invalid negative study-hour entries |
| `cleaned_student_data.csv` | 480-row cleaned dataset, zero missing values |
| `cleaning_summary.csv` | Before/after cleaning metrics (matches Section 7.2 table) |
| `student_performance.db` | Real SQLite database with the `students` table |
| `sql_query_results.md` | Output of every SQL query in Section 8, run live against the DB |
| `statistical_summary.csv` | Descriptive stats (mean/std/min/median/max) — Section 9.1 |
| `correlation_matrix.csv` | Full Pearson correlation matrix — Section 9.2 |
| `charts/10_1` – `charts/10_8` | All 8 visualizations from Section 10 |

## Notes on the numbers

The underlying dataset here is freshly generated (synthetic, seeded) rather
than a copy of the original report's data, so exact figures (e.g. average
overall % or the specific at-risk student IDs) won't match the PDF one-for-one.
What **does** match is the structure and the pattern of findings:
- Attendance and study hours are both strongly, positively correlated with
  overall performance.
- Final exam marks and internal marks correlate most strongly with overall %
  (expected, since they compose it).
- Age is essentially uncorrelated with performance.
- The grade distribution is bottom-heavy, with a large F-grade cluster.

If you want the model to reproduce the *exact* numbers from the PDF, swap
`raw_student_data.csv` for your real dataset (same column names) and re-run
steps 2–5 — the cleaning, SQL, and analytics logic is copied verbatim from the
report and needs no changes.
