"""
05_visualizations.py
Section 10 of the report: generates all 8 charts from the cleaned data.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

df = pd.read_csv("./cleaned_student_data.csv")
sns.set_style("whitegrid")
OUT = "./charts"
import os
os.makedirs(OUT, exist_ok=True)

palette = {"Pass": "#2e7d32", "Fail": "#c62828"}

# 10.1 Attendance vs Overall Marks
plt.figure(figsize=(7, 5))
sns.scatterplot(data=df, x="Attendance_Percentage", y="Overall_Percentage", hue="Pass_Fail", palette=palette, alpha=0.7)
sns.regplot(data=df, x="Attendance_Percentage", y="Overall_Percentage", scatter=False, color="black")
plt.title("Attendance Percentage vs Overall Marks")
plt.xlabel("Attendance (%)"); plt.ylabel("Overall Percentage")
plt.tight_layout(); plt.savefig(f"{OUT}/10_1_attendance_vs_marks.png", dpi=150); plt.close()

# 10.2 Study Hours vs Overall Marks
plt.figure(figsize=(7, 5))
sns.scatterplot(data=df, x="Study_Hours_per_Day", y="Overall_Percentage", hue="Pass_Fail", palette=palette, alpha=0.7)
sns.regplot(data=df, x="Study_Hours_per_Day", y="Overall_Percentage", scatter=False, color="black")
plt.title("Daily Study Hours vs Overall Marks")
plt.xlabel("Study Hours per Day"); plt.ylabel("Overall Percentage")
plt.tight_layout(); plt.savefig(f"{OUT}/10_2_study_hours_vs_marks.png", dpi=150); plt.close()

# 10.3 Grade Distribution
grade_order = ["O", "A+", "A", "B+", "B", "C", "F"]
grade_counts = df["Grade"].value_counts().reindex(grade_order).fillna(0)
plt.figure(figsize=(7, 5))
ax = sns.barplot(x=grade_counts.index, y=grade_counts.values, hue=grade_counts.index, palette="viridis", legend=False)
for i, v in enumerate(grade_counts.values):
    ax.text(i, v + 3, int(v), ha="center")
plt.title("Grade Distribution"); plt.xlabel("Grade"); plt.ylabel("Number of Students")
plt.tight_layout(); plt.savefig(f"{OUT}/10_3_grade_distribution.png", dpi=150); plt.close()

# 10.4 Department-wise Average Marks
dept_avg = df.groupby("Department")["Overall_Percentage"].mean().sort_values(ascending=False)
plt.figure(figsize=(7, 5))
ax = sns.barplot(x=dept_avg.index, y=dept_avg.values, hue=dept_avg.index, palette="mako", legend=False)
for i, v in enumerate(dept_avg.values):
    ax.text(i, v + 0.5, f"{v:.1f}", ha="center")
plt.title("Department-wise Average Overall Percentage")
plt.xlabel("Department"); plt.ylabel("Average Percentage")
plt.tight_layout(); plt.savefig(f"{OUT}/10_4_department_avg.png", dpi=150); plt.close()

# 10.5 Semester-wise Average Marks
sem_avg = df.groupby("Semester")["Overall_Percentage"].mean().sort_index()
plt.figure(figsize=(7, 5))
ax = sns.barplot(x=sem_avg.index, y=sem_avg.values, hue=sem_avg.index, palette="flare", legend=False)
for i, v in enumerate(sem_avg.values):
    ax.text(i, v + 0.5, f"{v:.1f}", ha="center")
plt.title("Semester-wise Average Overall Percentage")
plt.xlabel("Semester"); plt.ylabel("Average Percentage")
plt.tight_layout(); plt.savefig(f"{OUT}/10_5_semester_avg.png", dpi=150); plt.close()

# 10.6 Pass/Fail Distribution
pf_counts = df["Pass_Fail"].value_counts()
plt.figure(figsize=(6, 6))
plt.pie(pf_counts.values, labels=pf_counts.index, autopct="%1.1f%%",
        colors=[palette.get(k, "#999") for k in pf_counts.index], startangle=90)
plt.title("Pass / Fail Distribution")
plt.tight_layout(); plt.savefig(f"{OUT}/10_6_pass_fail_pie.png", dpi=150); plt.close()

# 10.7 Correlation Heatmap
num_cols = ["Age", "Attendance_Percentage", "Study_Hours_per_Day", "Assignment_Score",
            "Internal_Marks", "Final_Exam_Marks", "Overall_Percentage"]
corr = df[num_cols].corr(numeric_only=True)
plt.figure(figsize=(8, 6))
sns.heatmap(corr, annot=True, fmt=".2f", cmap="Reds", vmin=0, vmax=1)
plt.title("Correlation Heatmap of Academic & Behavioral Factors")
plt.tight_layout(); plt.savefig(f"{OUT}/10_7_correlation_heatmap.png", dpi=150); plt.close()

# 10.8 Assessment-wise Performance Comparison (scaled to 100)
assessment_avg = pd.Series({
    "Assignment_Score (avg)": df["Assignment_Score"].mean(),
    "Internal_Marks_Scaled(/100)": df["Internal_Marks"].mean() / 50 * 100,
    "Final_Exam_Marks (avg)": df["Final_Exam_Marks"].mean(),
})
plt.figure(figsize=(7, 5))
ax = sns.barplot(x=assessment_avg.index, y=assessment_avg.values, hue=assessment_avg.index, palette="crest", legend=False)
for i, v in enumerate(assessment_avg.values):
    ax.text(i, v + 0.5, f"{v:.1f}", ha="center")
plt.title("Assessment-wise Average Performance (scaled to 100)")
plt.ylabel("Average Score"); plt.xticks(rotation=15)
plt.tight_layout(); plt.savefig(f"{OUT}/10_8_assessment_comparison.png", dpi=150); plt.close()

print("All 8 visualizations generated in:", OUT)
for f in sorted(os.listdir(OUT)):
    print(" -", f)
