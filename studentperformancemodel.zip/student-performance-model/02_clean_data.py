"""
02_clean_data.py
Implements the cleaning pipeline described in Section 7.2:
  - remove duplicate Student_ID rows (keep first)
  - impute missing numeric fields with department-wise median
  - impute missing Gender with overall mode
  - standardize inconsistent Gender casing
  - treat negative Study_Hours_per_Day as missing, then impute
"""

import numpy as np
import pandas as pd

raw = pd.read_csv("./raw_student_data.csv")
before = {}
after = {}

before["Total Records"] = len(raw)
before["Duplicate Student IDs"] = raw["Student_ID"].duplicated().sum()
before["Missing Attendance_Percentage"] = raw["Attendance_Percentage"].isna().sum()
before["Missing Study_Hours_per_Day"] = raw["Study_Hours_per_Day"].isna().sum()
before["Missing Assignment_Score"] = raw["Assignment_Score"].isna().sum()
before["Missing Gender"] = raw["Gender"].isna().sum()
before["Invalid (negative) Study Hours"] = (raw["Study_Hours_per_Day"] < 0).sum()

df = raw.copy()

# 1. Standardize Gender casing BEFORE imputing mode
df["Gender"] = df["Gender"].str.strip().str.capitalize()
df["Gender"] = df["Gender"].replace({"Male": "Male", "Female": "Female"})

# 2. Remove duplicate Student_ID rows, keep first occurrence
df = df.drop_duplicates(subset="Student_ID", keep="first").reset_index(drop=True)

# 3. Negative study hours -> treat as missing
df.loc[df["Study_Hours_per_Day"] < 0, "Study_Hours_per_Day"] = np.nan

# 4. Impute numeric fields with department-wise median
for col in ["Attendance_Percentage", "Study_Hours_per_Day", "Assignment_Score"]:
    df[col] = df.groupby("Department")[col].transform(lambda s: s.fillna(s.median()))

# 5. Impute Gender with overall mode
mode_gender = df["Gender"].mode()[0]
df["Gender"] = df["Gender"].fillna(mode_gender)

# Recompute derived fields to keep internal consistency after imputation
df["Total_Marks"] = df["Internal_Marks"] + df["Final_Exam_Marks"]
df["Overall_Percentage"] = (df["Total_Marks"] / 150 * 100).round(1)


def grade_for(pct):
    if pct >= 90:
        return "O"
    if pct >= 80:
        return "A+"
    if pct >= 70:
        return "A"
    if pct >= 60:
        return "B+"
    if pct >= 50:
        return "B"
    if pct >= 40:
        return "C"
    return "F"


df["Grade"] = df["Overall_Percentage"].apply(grade_for)
df["Pass_Fail"] = np.where(df["Overall_Percentage"] >= 40, "Pass", "Fail")

after["Total Records"] = len(df)
after["Duplicate Student IDs"] = df["Student_ID"].duplicated().sum()
after["Missing Attendance_Percentage"] = df["Attendance_Percentage"].isna().sum()
after["Missing Study_Hours_per_Day"] = df["Study_Hours_per_Day"].isna().sum()
after["Missing Assignment_Score"] = df["Assignment_Score"].isna().sum()
after["Missing Gender"] = df["Gender"].isna().sum()
after["Invalid (negative) Study Hours"] = (df["Study_Hours_per_Day"] < 0).sum()

df.to_csv("./cleaned_student_data.csv", index=False)

summary = pd.DataFrame({"Before Cleaning": before, "After Cleaning": after})
summary.to_csv("./cleaning_summary.csv")
print(summary)
print(f"\nCleaned dataset saved: {len(df)} records -> cleaned_student_data.csv")
