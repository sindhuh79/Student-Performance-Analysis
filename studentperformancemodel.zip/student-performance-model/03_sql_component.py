"""
03_sql_component.py
Loads the cleaned data into a real SQLite database (students table),
then runs every SQL query from Section 8 of the report and prints/saves
the actual results.
"""

import sqlite3
import pandas as pd

df = pd.read_csv("./cleaned_student_data.csv")

conn = sqlite3.connect("./student_performance.db")
cur = conn.cursor()

cur.executescript(
    """
DROP TABLE IF EXISTS students;
CREATE TABLE students (
    Student_ID TEXT PRIMARY KEY,
    Gender TEXT,
    Age INTEGER,
    Department TEXT,
    Semester INTEGER,
    Attendance_Percentage REAL,
    Study_Hours_per_Day REAL,
    Assignment_Score REAL,
    Internal_Marks REAL,
    Final_Exam_Marks REAL,
    Total_Marks REAL,
    Overall_Percentage REAL,
    Grade TEXT,
    Pass_Fail TEXT
);
"""
)
df.to_sql("students", conn, if_exists="append", index=False)
conn.commit()

queries = {
    "8.2.1 Overall summary statistics": """
        SELECT
            MIN(Overall_Percentage) AS Min_Percentage,
            MAX(Overall_Percentage) AS Max_Percentage,
            ROUND(AVG(Overall_Percentage),2) AS Avg_Percentage,
            ROUND(AVG(Attendance_Percentage),2) AS Avg_Attendance,
            ROUND(AVG(Study_Hours_per_Day),2) AS Avg_Study_Hours
        FROM students;
    """,
    "8.2.2 Attendance-band vs performance": """
        SELECT
            CASE WHEN Attendance_Percentage < 75 THEN 'Below 75%' ELSE '75% and Above' END AS Attendance_Band,
            ROUND(AVG(Overall_Percentage),2) AS Avg_Percentage,
            COUNT(*) AS Num_Students
        FROM students
        GROUP BY Attendance_Band;
    """,
    "8.2.3 Study-hour band vs performance": """
        SELECT
            CASE
                WHEN Study_Hours_per_Day < 2 THEN '<2 hrs'
                WHEN Study_Hours_per_Day < 4 THEN '2-4 hrs'
                WHEN Study_Hours_per_Day < 6 THEN '4-6 hrs'
                ELSE '6+ hrs'
            END AS Study_Band,
            ROUND(AVG(Overall_Percentage),2) AS Avg_Percentage,
            COUNT(*) AS Num_Students
        FROM students
        GROUP BY Study_Band
        ORDER BY Avg_Percentage;
    """,
    "8.3.1 Department-wise average performance": """
        SELECT Department,
            ROUND(AVG(Overall_Percentage),2) AS Avg_Percentage,
            ROUND(AVG(Attendance_Percentage),2) AS Avg_Attendance,
            COUNT(*) AS Num_Students
        FROM students
        GROUP BY Department
        ORDER BY Avg_Percentage DESC;
    """,
    "8.3.2 Semester-wise average performance": """
        SELECT Semester,
            ROUND(AVG(Overall_Percentage),2) AS Avg_Percentage,
            COUNT(*) AS Num_Students
        FROM students
        GROUP BY Semester
        ORDER BY Semester;
    """,
    "8.3.3 Grade distribution": """
        SELECT Grade, COUNT(*) AS Num_Students,
            ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM students),2) AS Percentage
        FROM students
        GROUP BY Grade
        ORDER BY Num_Students DESC;
    """,
    "8.3.4 Overall pass/fail percentage": """
        SELECT Pass_Fail, COUNT(*) AS Num_Students,
            ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM students),2) AS Percentage
        FROM students
        GROUP BY Pass_Fail;
    """,
    "8.3.5 Department-wise pass percentage": """
        SELECT Department,
            ROUND(100.0*SUM(CASE WHEN Pass_Fail='Pass' THEN 1 ELSE 0 END)/COUNT(*),2) AS Pass_Percentage,
            COUNT(*) AS Num_Students
        FROM students
        GROUP BY Department
        ORDER BY Pass_Percentage DESC;
    """,
    "8.4.1 Top 10 performing students": """
        SELECT Student_ID, Department, Overall_Percentage, Grade
        FROM students
        ORDER BY Overall_Percentage DESC
        LIMIT 10;
    """,
    "8.4.2 At-risk students (Overall % below 45)": """
        SELECT Student_ID, Department, Attendance_Percentage, Overall_Percentage, Grade
        FROM students
        WHERE Overall_Percentage < 45
        ORDER BY Overall_Percentage ASC
        LIMIT 10;
    """,
}

with open("./sql_query_results.md", "w") as f:
    f.write("# SQL Query Results (run against student_performance.db)\n\n")
    for title, q in queries.items():
        result = pd.read_sql_query(q, conn)
        print(f"\n=== {title} ===")
        print(result.to_string(index=False))
        f.write(f"## {title}\n\n")
        f.write("```sql\n" + q.strip() + "\n```\n\n")
        f.write(result.to_markdown(index=False) + "\n\n")

conn.close()
print("\nAll queries executed successfully against student_performance.db")
print("Results saved -> sql_query_results.md")
