"""
04_analytics.py
Section 9 of the report: descriptive statistics + Pearson correlation matrix.
"""
import pandas as pd

df = pd.read_csv("./cleaned_student_data.csv")

num_cols = [
    "Attendance_Percentage",
    "Study_Hours_per_Day",
    "Assignment_Score",
    "Internal_Marks",
    "Final_Exam_Marks",
    "Overall_Percentage",
]

summary = df[num_cols].agg(["mean", "std", "min", "median", "max"]).T.round(2)
summary.columns = ["Mean", "Std. Dev.", "Min", "Median", "Max"]
print("=== 9.1 Statistical Summary ===")
print(summary)

corr = df[["Age"] + num_cols].corr(numeric_only=True).round(2)
print("\n=== 9.2 Correlation with Overall_Percentage ===")
print(corr["Overall_Percentage"].sort_values(ascending=False))

summary.to_csv("./statistical_summary.csv")
corr.to_csv("./correlation_matrix.csv")
print("\nSaved -> statistical_summary.csv, correlation_matrix.csv")
