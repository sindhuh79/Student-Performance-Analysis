"""
01_generate_raw_data.py
Generates a synthetic RAW student dataset (490 records) with realistic
data-quality problems: duplicates, missing values, inconsistent text casing,
and invalid (negative) study-hour entries -- mirroring Section 7.2 of the
report ("Data Cleaning and Preprocessing").
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N = 480  # clean target count; we'll inject issues on top of this
DEPARTMENTS = ["CSE", "ISE", "ECE", "AIML", "CIVIL"]
SEMESTERS = [3, 4, 5, 6]

student_ids = [f"STU{1000 + i}" for i in range(N)]
genders = np.random.choice(["Male", "Female"], size=N, p=[0.55, 0.45])
ages = np.random.randint(19, 23, size=N)
departments = np.random.choice(DEPARTMENTS, size=N, p=[0.32, 0.22, 0.16, 0.20, 0.10])
semesters = np.random.choice(SEMESTERS, size=N)

# --- Behavioral factors (root causes) ---
# Attendance: 40-100, roughly normal
attendance = np.clip(np.random.normal(71, 11, size=N), 35, 100)

# Study hours: correlated loosely with attendance but with own variance
study_hours = np.clip(
    0.35 * (attendance - 71) / 11 + np.random.normal(3.1, 1.7, size=N), 0, 8
)

# --- Academic outcomes, built from behavioral factors + noise so that
#     correlations resemble the report (attendance/study hours strongly
#     predictive, with final exam marks the "noisiest" of the three) ---
def scale(x, lo, hi):
    return np.clip(lo + (hi - lo) * (x - x.min()) / (x.max() - x.min()), lo, hi)

base_ability = 0.55 * scale(attendance, 0, 1) + 0.45 * scale(study_hours, 0, 1)

assignment_score = np.clip(
    100 * base_ability + np.random.normal(0, 10, size=N), 15, 100
)
internal_marks = np.clip(
    50 * base_ability + np.random.normal(0, 5, size=N), 5, 50
)
final_exam_marks = np.clip(
    100 * base_ability + np.random.normal(0, 14, size=N) - 8, 0, 100
)

total_marks = internal_marks + final_exam_marks  # out of 150
overall_pct = total_marks / 150 * 100


def grade_for(pct):
    if pct >= 90:
        return "O"
    if pct >= 80:
        return "A+"
    if pct >= 70:
        return "A"
    if pct >= 60:
        return "B+"
    if pct >= 50:
        return "B"
    if pct >= 40:
        return "C"
    return "F"


grades = [grade_for(p) for p in overall_pct]
pass_fail = ["Pass" if p >= 40 else "Fail" for p in overall_pct]

df = pd.DataFrame(
    {
        "Student_ID": student_ids,
        "Gender": genders,
        "Age": ages,
        "Department": departments,
        "Semester": semesters,
        "Attendance_Percentage": attendance.round(1),
        "Study_Hours_per_Day": study_hours.round(1),
        "Assignment_Score": assignment_score.round(1),
        "Internal_Marks": internal_marks.round(1),
        "Final_Exam_Marks": final_exam_marks.round(1),
        "Total_Marks": total_marks.round(1),
        "Overall_Percentage": overall_pct.round(1),
        "Grade": grades,
        "Pass_Fail": pass_fail,
    }
)

# ---------------------------------------------------------------
# Inject the data-quality problems described in Section 7.2
# ---------------------------------------------------------------
raw = df.copy()

# 1. Duplicate rows (10 duplicate Student_IDs)
dupe_rows = raw.sample(10, random_state=1)
raw = pd.concat([raw, dupe_rows], ignore_index=True)

# 2. Missing values
for col, n_missing, seed in [
    ("Attendance_Percentage", 9, 2),
    ("Study_Hours_per_Day", 7, 3),
    ("Assignment_Score", 9, 4),
    ("Gender", 4, 5),
]:
    idx = raw.sample(n_missing, random_state=seed).index
    raw.loc[idx, col] = np.nan

# 3. Inconsistent text casing in Gender
idx = raw.dropna(subset=["Gender"]).sample(12, random_state=6).index
raw.loc[idx, "Gender"] = raw.loc[idx, "Gender"].str.lower()
idx2 = raw.dropna(subset=["Gender"]).sample(8, random_state=7).index
raw.loc[idx2, "Gender"] = raw.loc[idx2, "Gender"].str.upper()

# 4. Invalid (negative) study hours -- data entry errors
idx = raw.dropna(subset=["Study_Hours_per_Day"]).sample(2, random_state=8).index
raw.loc[idx, "Study_Hours_per_Day"] = -abs(raw.loc[idx, "Study_Hours_per_Day"])

# Shuffle row order so duplicates aren't conveniently at the end
raw = raw.sample(frac=1, random_state=9).reset_index(drop=True)

raw.to_csv("./raw_student_data.csv", index=False)
print(f"Raw dataset generated: {len(raw)} records -> raw_student_data.csv")
print(raw.isna().sum())
